class VoiceRecorder {
    constructor() {
        this.mediaRecorder = null;
        this.audioStream = null;
        this.chunks = [];
        this.isRecording = false;
        this.chunkDuration = 2000; // 2 seconds in milliseconds
        this.currentChunkData = [];
        this.chunkTimer = null;
        this.totalTimer = null;
        this.startTime = null;
        this.currentChunkStartTime = null;
        
        this.initializeElements();
        this.bindEvents();
    }
    
    initializeElements() {
        this.startBtn = document.getElementById('startBtn');
        this.stopBtn = document.getElementById('stopBtn');
        this.playAllBtn = document.getElementById('playAllBtn');
        this.clearBtn = document.getElementById('clearBtn');
        this.status = document.getElementById('status');
        this.timer = document.getElementById('timer');
        this.totalTime = document.getElementById('totalTime');
        this.chunkTimer = document.getElementById('chunkTimer');
        this.chunkTime = document.getElementById('chunkTime');
        this.chunksContainer = document.getElementById('chunksContainer');
        this.noChunks = document.getElementById('noChunks');
    }
    
    bindEvents() {
        this.startBtn.addEventListener('click', () => this.startRecording());
        this.stopBtn.addEventListener('click', () => this.stopRecording());
        this.playAllBtn.addEventListener('click', () => this.playAllChunks());
        this.clearBtn.addEventListener('click', () => this.clearAllChunks());
    }
    
    async startRecording() {
        try {
            // Request microphone access
            this.audioStream = await navigator.mediaDevices.getUserMedia({ 
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                } 
            });
            
            // Create MediaRecorder instance
            this.mediaRecorder = new MediaRecorder(this.audioStream, {
                mimeType: 'audio/webm;codecs=opus'
            });
            
            this.setupMediaRecorderEvents();
            this.startRecordingSession();
            
        } catch (error) {
            console.error('Error accessing microphone:', error);
            this.updateStatus('Error: Could not access microphone', 'error');
        }
    }
    
    setupMediaRecorderEvents() {
        this.mediaRecorder.ondataavailable = (event) => {
            if (event.data.size > 0) {
                // Each event is a 2s chunk
                const chunkBlob = event.data;
                const chunkUrl = URL.createObjectURL(chunkBlob);
                const chunk = {
                    id: this.chunks.length + 1,
                    blob: chunkBlob,
                    url: chunkUrl,
                    duration: 2.0,
                    timestamp: new Date().toLocaleTimeString()
                };
                this.chunks.push(chunk);
                this.addChunkToUI(chunk);
                this.updateChunkControls();
            }
        };
        this.mediaRecorder.onstop = () => {
            this.updateUIForStopped();
        };
    }
    
    startRecordingSession() {
        this.isRecording = true;
        this.startTime = Date.now();
        this.updateUIForRecording();
        // Start recording with 2s timeslice
        this.currentChunkStartTime = Date.now();
        this.mediaRecorder.start(this.chunkDuration);
        this.updateChunkTimer();
    }
    
    // Removed: startNewChunk. Not needed with timeslice chunking.
    
    // Removed: finalizeCurrentChunk. Not needed with timeslice chunking.
    
    stopRecording() {
        this.isRecording = false;
        if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
            this.mediaRecorder.stop();
        }
        if (this.audioStream) {
            this.audioStream.getTracks().forEach(track => track.stop());
        }
        this.clearTimers();
        // UI update now handled in onstop
    }
    
    updateUIForRecording() {
        this.startBtn.disabled = true;
        this.stopBtn.disabled = false;
        this.updateStatus('Recording in progress...', 'recording');
        this.timer.style.display = 'block';
        this.chunkTimer.style.display = 'block';
        this.startTotalTimer();
    }
    
    updateUIForStopped() {
        this.startBtn.disabled = false;
        this.stopBtn.disabled = true;
        this.updateStatus('Recording stopped', 'ready');
        this.timer.style.display = 'none';
        this.chunkTimer.style.display = 'none';
    }
    
    updateStatus(message, type = 'ready') {
        this.status.textContent = message;
        this.status.className = `status ${type}`;
    }
    
    startTotalTimer() {
        this.totalTimer = setInterval(() => {
            if (this.startTime) {
                const elapsed = (Date.now() - this.startTime) / 1000;
                const minutes = Math.floor(elapsed / 60);
                const seconds = Math.floor(elapsed % 60);
                this.totalTime.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
        }, 1000);
    }
    
    updateChunkTimer() {
        this.chunkTimerInterval = setInterval(() => {
            if (this.currentChunkStartTime && this.isRecording) {
                const elapsed = (Date.now() - this.currentChunkStartTime) / 1000;
                const remaining = Math.max(0, 2.0 - elapsed);
                this.chunkTime.textContent = `${elapsed.toFixed(1)}`;
            }
        }, 100);
    }
    
    clearTimers() {
        if (this.totalTimer) {
            clearInterval(this.totalTimer);
            this.totalTimer = null;
        }
        if (this.chunkTimerInterval) {
            clearInterval(this.chunkTimerInterval);
            this.chunkTimerInterval = null;
        }
    }
    
    addChunkToUI(chunk) {
        if (this.noChunks.style.display !== 'none') {
            this.noChunks.style.display = 'none';
        }
        
        const chunkElement = document.createElement('div');
        chunkElement.className = 'chunk-item';
        chunkElement.innerHTML = `
            <div class="chunk-info">
                <strong>Chunk ${chunk.id}</strong> - ${chunk.timestamp} (${chunk.duration}s)
            </div>
            <div class="chunk-controls">
                <button class="play-btn" onclick="recorder.playChunk(${chunk.id - 1})">Play</button>
                <button class="clear-btn" onclick="recorder.deleteChunk(${chunk.id - 1})">Delete</button>
            </div>
        `;
        
        this.chunksContainer.appendChild(chunkElement);
    }
    
    updateChunkControls() {
        this.playAllBtn.disabled = this.chunks.length === 0;
        this.clearBtn.disabled = this.chunks.length === 0;
    }
    
    playChunk(index) {
        if (index >= 0 && index < this.chunks.length) {
            let playUrl;
            if (index === 0) {
                playUrl = this.chunks[0].url;
            } else {
                // Repackage: prepend header from first chunk
                const headerPromise = this.chunks[0].blob.arrayBuffer();
                const chunkPromise = this.chunks[index].blob.arrayBuffer();
                Promise.all([headerPromise, chunkPromise]).then(([headerBuf, chunkBuf]) => {
                    // Use first 1KB of header (empirical, may need tuning)
                    const header = new Uint8Array(headerBuf).slice(0, 1024);
                    const chunk = new Uint8Array(chunkBuf);
                    const combined = new Uint8Array(header.length + chunk.length);
                    combined.set(header, 0);
                    combined.set(chunk, header.length);
                    const repackBlob = new Blob([combined], { type: 'audio/webm;codecs=opus' });
                    const repackUrl = URL.createObjectURL(repackBlob);
                    const audio = new Audio(repackUrl);
                    audio.play().catch(error => {
                        console.error('Error playing chunk:', error);
                    });
                });
                return;
            }
            const audio = new Audio(playUrl);
            audio.play().catch(error => {
                console.error('Error playing chunk:', error);
            });
        }
    }
    
    async playAllChunks() {
        if (this.chunks.length === 0) return;
        
        this.updateStatus('Playing all chunks...', 'recording');
        
        for (let i = 0; i < this.chunks.length; i++) {
            const audio = new Audio(this.chunks[i].url);
            
            try {
                await new Promise((resolve, reject) => {
                    audio.onended = resolve;
                    audio.onerror = reject;
                    audio.play();
                });
                
                // Small pause between chunks
                await new Promise(resolve => setTimeout(resolve, 100));
                
            } catch (error) {
                console.error(`Error playing chunk ${i + 1}:`, error);
                break;
            }
        }
        
        this.updateStatus('Playback completed', 'ready');
    }
    
    deleteChunk(index) {
        if (index >= 0 && index < this.chunks.length) {
            // Revoke the object URL to free memory
            URL.revokeObjectURL(this.chunks[index].url);
            
            // Remove chunk from array
            this.chunks.splice(index, 1);
            
            // Re-render chunks
            this.renderChunks();
            this.updateChunkControls();
        }
    }
    
    clearAllChunks() {
        if (confirm('Are you sure you want to delete all recorded chunks?')) {
            // Revoke all object URLs
            this.chunks.forEach(chunk => URL.revokeObjectURL(chunk.url));
            
            // Clear chunks array
            this.chunks = [];
            
            // Re-render UI
            this.renderChunks();
            this.updateChunkControls();
            this.updateStatus('All chunks cleared', 'ready');
        }
    }
    
    renderChunks() {
        // Clear existing chunks
        const chunkElements = this.chunksContainer.querySelectorAll('.chunk-item');
        chunkElements.forEach(element => element.remove());
        
        if (this.chunks.length === 0) {
            this.noChunks.style.display = 'block';
        } else {
            this.noChunks.style.display = 'none';
            
            // Re-add all chunks with updated indices
            this.chunks.forEach((chunk, index) => {
                chunk.id = index + 1; // Update chunk ID
                this.addChunkToUI(chunk);
            });
        }
    }
    
    // Method to download all chunks as separate files
    downloadChunk(index) {
        if (index >= 0 && index < this.chunks.length) {
            const chunk = this.chunks[index];
            const link = document.createElement('a');
            link.href = chunk.url;
            link.download = `voice_chunk_${chunk.id}.webm`;
            link.click();
        }
    }
    
    // Method to combine all chunks into a single audio file
    async combineChunks() {
        if (this.chunks.length === 0) return null;
        
        try {
            const combinedChunks = [];
            
            for (const chunk of this.chunks) {
                const arrayBuffer = await chunk.blob.arrayBuffer();
                combinedChunks.push(new Uint8Array(arrayBuffer));
            }
            
            // Simple concatenation (note: this may not work perfectly for all audio formats)
            const totalLength = combinedChunks.reduce((sum, chunk) => sum + chunk.length, 0);
            const combined = new Uint8Array(totalLength);
            
            let offset = 0;
            combinedChunks.forEach(chunk => {
                combined.set(chunk, offset);
                offset += chunk.length;
            });
            
            return new Blob([combined], { type: 'audio/webm;codecs=opus' });
            
        } catch (error) {
            console.error('Error combining chunks:', error);
            return null;
        }
    }
}

// Initialize the recorder when the page loads
let recorder;

document.addEventListener('DOMContentLoaded', () => {
    recorder = new VoiceRecorder();
    
    // Check for browser support
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        document.getElementById('status').textContent = 'Error: Browser does not support audio recording';
        document.getElementById('status').className = 'status error';
        document.getElementById('startBtn').disabled = true;
    }
});